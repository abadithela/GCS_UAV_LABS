/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package data;


/**
 *
 * @author dernehl
 */
public class ParamPacket {
    private final byte[] HEADER = { 'U', 'U', 'T'};
    private byte[] packet;
    private final int HEADER_SIZE = HEADER.length;
    private final int PAYLOAD_SIZE = 5;
    private final int CHECKSUM_SIZE = 1;
    private final int PACKET_SIZE = HEADER_SIZE + PAYLOAD_SIZE + CHECKSUM_SIZE;
    
    public byte[] getPacketData(){
        return packet;
    }            
    
    public ParamPacket(){
        packet = new byte[PACKET_SIZE];
        assembleHeader();
    }
    
    private void assembleHeader(){
        for(int i = 0; i < HEADER_SIZE; ++i){
            packet[i] = HEADER[i];
        }
    }           
    
    public void assembleParameterPacket(byte paramId, float value)
    {
        //header should be assembled already
        packet[HEADER_SIZE + 0] = paramId;        
        int valBytes = Float.floatToRawIntBits(value);
        for(int i = 0; i < 4; ++i){
            int mask = 0xFF << (8*(3-i));                        
            packet[HEADER_SIZE + 1 + i] = (byte)((valBytes & mask) >> (8*(3-i)));
        }
    }
    
}
