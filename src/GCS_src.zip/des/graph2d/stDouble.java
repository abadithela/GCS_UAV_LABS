/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package des.graph2d;

/**
 *
 * @author des2010a
 */
class stDouble {

}
