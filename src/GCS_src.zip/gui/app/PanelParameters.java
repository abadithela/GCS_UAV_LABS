/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package gui.app;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.embed.swing.JFXPanel;
import javafx.scene.Scene;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author dernehl
 */
public class PanelParameters extends javax.swing.JPanel {

    private JLabel[] watchDescriptions;
    private JLabel[] watchValues;
    private JCheckBox[] watchValuesScoped;
    private JLabel[] paramDescriptions;
    private JTextField[] paramValues;
    private JButton sendParam;
    private final int watchCount = 10;
    private final int paramCount = 10;
    private final int textWidth = 50;
    private float[] oldParams;
    private ArrayList<Integer> paramsToSend = new ArrayList<Integer>();
    private String[] watchNames;
    private XYChart.Series allWatchesSeries[];
    private LineChart<Number, Number> chart;
    private JPanel chartPanel = new JPanel();
    private JFXPanel chartPanelfx = new JFXPanel();
    private boolean FXinited = false;
    private final int NUMBER_OF_DATAPOINTS_ON_CHART = 50*60; // 50 Hz * 60s
    private NumberAxis xAxis;
    private NumberAxis yAxis;
    
    /**
     * Creates new form PanelParameters
     */
    public PanelParameters() {
        initComponents();                

        oldParams = new float[paramCount];
        
        watchDescriptions = new JLabel[watchCount];
        watchValues = new JLabel[watchCount];
        watchValuesScoped = new JCheckBox[watchCount];
        watchNames = new String[watchCount];
        
        paramDescriptions = new JLabel[paramCount];
        paramValues = new JTextField[paramCount];
        String[] paramNames = new String[paramCount];
        
        for(int i = 0; i < paramCount; ++i){
            paramsToSend.add(i);
        }            
        
        try{            
            BufferedReader spec = new BufferedReader(new InputStreamReader(new FileInputStream("signals.txt")));
            for(int i = 0; i < watchCount; i++) {
                paramNames[i] = spec.readLine();
            }
            for(int i = 0; i < watchCount; i++) {
                watchNames[i] = spec.readLine();
            }            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(PanelParameters.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(PanelParameters.class.getName()).log(Level.SEVERE, null, ex);
        }

        GridBagLayout layout = new GridBagLayout();
        GridBagConstraints c = new GridBagConstraints();
        this.setLayout(layout);
        for(int i = 0; i < watchCount; ++i)
        {            
            watchValuesScoped[i] = new JCheckBox();            
            watchValues[i] = new JLabel();
            watchValues[i].setText("Value " + (1 + i));
            watchDescriptions[i] = new JLabel();             
            if(watchNames[i] == null || watchNames[i].isEmpty() ||
                    watchNames[i].compareTo("Unused Scope") == 0){
                watchDescriptions[i].setText("Watch " + (1 + i) + ":");
                watchValuesScoped[i].setSelected(false);
            } else {
                watchDescriptions[i].setText(watchNames[i]);   
                watchValuesScoped[i].setSelected(true);
            }            
            watchValues[i].setMinimumSize(new Dimension(40,15));
            watchValues[i].setPreferredSize(new Dimension(40,15));
            watchValues[i].setMaximumSize(new Dimension(40,15));
            watchValues[i].setHorizontalTextPosition(JLabel.RIGHT);

            watchValuesScoped[i].addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                    updateChartSelection();
                }
            });
            
            c.gridx = 0;
            c.gridy = i;
            c.anchor = GridBagConstraints.LINE_START;
            c.ipadx = 10;
            c.fill = GridBagConstraints.NONE;
            this.add(watchDescriptions[i], c);            
            c.gridx  = 1;
            c.anchor = GridBagConstraints.LINE_END;
            this.add(watchValues[i], c);
            c.gridx = 2;
            this.add(watchValuesScoped[i],c);
                       
        }
        
        for(int i = 0; i < paramCount; ++i)
        {            
            paramValues[i] = new JTextField();
            //paramValues[i].setText("0.0");
            paramValues[i].setText("0.0");
            paramDescriptions[i] = new JLabel();            
            if(paramNames[i] == null || paramNames[i].isEmpty()){
                paramDescriptions[i].setText("Param " + (1 + i) + ":");
            } else {
                paramDescriptions[i].setText(paramNames[i]);
            }
            paramValues[i].setMinimumSize(new Dimension(textWidth,20));
            paramValues[i].setPreferredSize(new Dimension(textWidth,20));
            paramValues[i].setMaximumSize(new Dimension(textWidth,20));
            paramValues[i].setHorizontalAlignment(JTextField.RIGHT);
            paramValues[i].setBackground(Color.ORANGE);
            paramValues[i].addKeyListener(new java.awt.event.KeyListener() {

                public void keyTyped(KeyEvent e) {
                    
                }

                public void keyPressed(KeyEvent e) {
                    
                }

                public void keyReleased(KeyEvent e) {                    
                    JTextField field = (JTextField) e.getSource();
                    field.setBackground(Color.ORANGE);
                    paramsToSend.add(getIdFromTextField(field));
                }
            });
            c.gridx = 0;
            c.gridy = watchCount + i;
            c.anchor = GridBagConstraints.LINE_START;
            c.ipadx = 10;
            c.fill = GridBagConstraints.NONE;
            this.add(paramDescriptions[i], c);            
            c.gridx  = 1;
            c.anchor = GridBagConstraints.LINE_END;                        
            this.add(paramValues[i], c);
        }       
        

        
        sendParam = new JButton();
        sendParam.setText("Send Data");
        sendParam.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sendParam.setEnabled(false);
                for(Integer i : paramsToSend)
                {
                    if(i == -1)
                        continue;
                    Float val = Float.parseFloat(paramValues[i].getText());
                    oldParams[i] = val;
                    kernel.Kernel.getInstance().sendParameter((byte)(1+i), val);                    
                }
                paramsToSend.clear();
                sendParam.setEnabled(true);
            }
        });
        c.gridx = 1;
        c.gridy = watchCount + paramCount;
        this.add(sendParam, c);
              

        Platform.runLater(new Runnable() {
            public void run() {
                initFX(); 
            }
        });
               
        revalidate();     
        updateChartSelection();
    }
    
    
    private void initFX(){
        xAxis = new NumberAxis();
        yAxis = new NumberAxis();
        xAxis.setLabel("time [s]");
        yAxis.setLabel("");
        chart = new LineChart<Number, Number>(xAxis, yAxis);
        chart.setCreateSymbols(false);
        allWatchesSeries = new XYChart.Series[watchCount];
        for(int i = 0; i < watchCount; ++i)
        {            
            allWatchesSeries[i] = new XYChart.Series();            
            if(watchNames[i] == null || watchNames[i].isEmpty() ||
                    watchNames[i].compareTo("Unused Scope") == 0){
                allWatchesSeries[i].setName("Series " + (1+i));  
            } else {
                allWatchesSeries[i].setName(watchNames[i]);     
            }            
            chart.getData().add(allWatchesSeries[i]);    
        }
        
        Scene scene = new Scene(chart, 500, 350);        
        chartPanelfx.setScene(scene);
        chartPanel.add(chartPanelfx);
        chartPanel.setPreferredSize(new Dimension(500,350));
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 3;
        c.gridy = 0;        
        c.gridheight = watchCount + paramCount;
        this.add(chartPanel, c);
        
        FXinited = true;
        updateChartSelection();
    }
    
    private int getIdFromTextField(JTextField reference){
        for(int i = 0; i < paramCount; ++i){
            if(reference == paramValues[i])
                return i;
        }            
        return -1;
    }
    
    synchronized void setValues(final double[] values, final double time)
    {
        if(!FXinited)
            return;
        Platform.runLater(new Runnable() {
            public void run() {
               for(int i = 0; i < watchCount; ++i)
               {
                    watchValues[i].setText(Double.toString(values[i]));
                    if(allWatchesSeries[i].getData().size() >= NUMBER_OF_DATAPOINTS_ON_CHART){
                        allWatchesSeries[i].getData().remove(0);
                        XYChart.Data<Number, Number> oldest = (XYChart.Data<Number, Number>) allWatchesSeries[i].getData().get(0);                        
                        xAxis.setLowerBound(oldest.getXValue().doubleValue());
                        xAxis.setUpperBound(time);
                        xAxis.setAutoRanging(false);
                    }
                    allWatchesSeries[i].getData().add( 
                        new XYChart.Data( time, values[i]));                    
                }        
                chartPanel.revalidate();
            }
        });
        

    }
    
    void setParams(double[] values)
    {
        for(int i = 0; i < paramCount; ++i)
        {
            float oldValue = oldParams[i];
            float newValue = (float) values[i];
            if(oldValue != newValue)
            {
                paramValues[i].setText(Float.toString(newValue));                
                oldParams[i] = newValue;
            }
            boolean userChangedButNotSent = Float.parseFloat(paramValues[i].getText()) != oldValue;
            if(paramValues[i].getBackground() != Color.GREEN && !userChangedButNotSent)
                paramValues[i].setBackground(Color.GREEN);
        }
    }         
    
    private void updateChartSelection(){
        if(!FXinited)
            return;
        Platform.runLater(new Runnable() {
            public void run() {
                chart.getData().clear();
                for(int i = 0; i < watchCount; ++i){
                if(watchValuesScoped[i].isSelected()){
                    chart.getData().add(allWatchesSeries[i]);                
                }
            }
            }
        });

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
