/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package kernel;

/**
 *
 * @author David Escobar Sanabria
 */
public interface KernelInterface {

   
   public double getLongitud();
   public double getLatitud();
   public double getAltitude();
   

}
